<li><a href="/admin-analisis/pelanggan">Transaksi Terbanyak</a></li>
<li><a href="/admin-analisis/pelanggan/total-transaksi-terbanyak">Total transaksi Terbanyak </a></li>
<li><a href="/admin-analisis/pelanggan/jenis-kelamin">Jenis Kelamin </a></li>